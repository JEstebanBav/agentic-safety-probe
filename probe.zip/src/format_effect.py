"""
Specificity and scale of the format effect.

DeltaP alone cannot answer the research question. It measures how far the
harmful centroid moves along d_chat when the format changes, and three very
different mechanisms produce the same number:

  1. The refusal representation genuinely weakens for harmful requests.
     This is the thesis's claim.

  2. The agentic context displaces EVERY representation along d_chat by a
     common offset. The refusal mechanism is untouched; only the origin moved.
     A rigid translation leaves the harmful/benign contrast intact.

  3. The agentic context contracts the SCALE of the projection. Activation
     norms are arbitrary units, and if the whole distribution shrinks, both
     the between-class distance and the within-class spread shrink together.
     Nothing about detection has changed, but DeltaP is large.

The methodology chapter already argues that projections are not comparable
across layers without normalisation, because the norm of the residual stream
grows with depth. That same argument applies across FORMATS, and for the same
reason: the agentic prompt is longer and its activations live at a different
scale. Reporting a raw DeltaP across formats repeats, between conditions, the
error the chapter forbids between layers.

This module supplies the two contrasts that separate the three mechanisms:

  BENIGN CONTROL (difference-in-differences)
      Compare the paired shift of harmful prompts against the paired shift of
      benign ones. Mechanism 2 predicts the two shifts are equal and the
      interaction vanishes. Only a harmful-specific interaction supports the
      thesis. This is the first objection any examiner raises, and the corpus
      already contains the benign arm needed to answer it.

  SCALE-INVARIANT EFFECT
      Re-express the format effect in units that survive a change of scale:
      the standardised class separation, and the AUROC. If the raw separation
      falls by 40% while the standardised separation falls by 10%, then three
      quarters of the apparent weakening was a change of units.

AUROC is reported alongside because it is scale-invariant by construction, but
it saturates: once separation exceeds roughly three pooled standard
deviations, AUROC sits at the ceiling and is blind to further change. It
certifies that detection survives; it cannot measure how much margin was lost.
The standardised separation covers exactly that gap.
"""

from __future__ import annotations

import numpy as np
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

from sklearn.metrics import roc_auc_score

from .robust_estimation import (
    paired_bootstrap_ci,
    paired_cohens_d,
    paired_permutation_test,
    paired_sign_test,
    paired_ttest_directional,
    pooled_cohens_d,
)


# ============================================================
# RESULT CONTAINERS
# ============================================================

@dataclass
class SpecificityResult:
    """Difference-in-differences: is the format shift specific to harmful prompts?"""
    layer_idx: int
    n_harmful: int
    n_benign: int
    delta_p_harmful: float          # mean(chat_h - agent_h), the reported effect
    delta_p_benign: float           # mean(chat_b - agent_b), the control
    interaction: float              # harmful shift minus benign shift
    # Is the benign arm moving at all?
    benign_shift_p: float
    # Is the interaction real?
    interaction_p: float
    interaction_cohens_d: float
    interaction_ci_lower: float
    interaction_ci_upper: float
    # Share of the headline effect that is NOT specific to harmfulness
    common_shift_fraction: float

    @property
    def is_specific(self) -> bool:
        """True when the effect cannot be explained by a rigid common shift."""
        return self.interaction_p < 0.05 and self.interaction > 0


@dataclass
class ScaleResult:
    """The format effect expressed in raw, standardised and rank units."""
    layer_idx: int
    # Raw units (scale-dependent — what the pipeline reports today)
    separation_chat: float
    separation_agent: float
    separation_loss_raw: float          # fractional loss, raw units
    # Standardised units (scale-invariant)
    pooled_sd_chat: float
    pooled_sd_agent: float
    cohens_d_chat: float
    cohens_d_agent: float
    separation_loss_standardised: float
    # Rank units (scale-invariant, saturating)
    auroc_chat: float
    auroc_agent: float
    auroc_loss: float
    # How much of the raw loss was a change of units rather than of separability
    scale_contraction: float            # pooled_sd_agent / pooled_sd_chat

    @property
    def raw_loss_is_inflated(self) -> bool:
        """True when the raw loss materially overstates the standardised one."""
        return self.separation_loss_raw > self.separation_loss_standardised + 0.10


@dataclass
class StratumDetection:
    """Detection capability within one explicitness stratum, per format."""
    stratum: str
    n_harmful: int
    n_benign: int
    auroc_chat: float
    auroc_agent: float
    auroc_loss: float
    cohens_d_chat: float
    cohens_d_agent: float
    separation_loss_standardised: float


# ============================================================
# 1. BENIGN CONTROL  (difference-in-differences)
# ============================================================

def format_effect_specificity(
    chat_harmful: np.ndarray,
    agent_harmful: np.ndarray,
    chat_benign: np.ndarray,
    agent_benign: np.ndarray,
    direction: np.ndarray,
    layer_idx: int = -1,
    n_permutations: int = 10000,
    n_boot: int = 10000,
    seed: int = 42,
) -> SpecificityResult:
    """
    Test whether the agentic shift is specific to harmful requests.

    Both arms are paired within themselves (a prompt appears in both formats),
    so each arm's shift is a within-pair difference. The two arms are distinct
    prompts, however, so the interaction between them is a between-group
    contrast on those differences.

    Interpretation:
        interaction ~ 0        the format translates everything equally; the
                               refusal mechanism is not selectively weakened
        interaction > 0        harmful prompts lose more projection than benign
                               ones, which is the thesis's claim
        interaction < 0        the direction responds MORE to harm under the
                               agentic format

    Args:
        chat_harmful, agent_harmful: paired row-wise, (n_h, hidden_dim).
        chat_benign, agent_benign:   paired row-wise, (n_b, hidden_dim).
        direction: the refusal direction for this layer, (hidden_dim,).

    Returns:
        SpecificityResult.
    """
    if len(chat_harmful) != len(agent_harmful):
        raise ValueError("harmful arm is not paired row-wise")
    if len(chat_benign) != len(agent_benign):
        raise ValueError("benign arm is not paired row-wise")

    shift_h = chat_harmful @ direction - agent_harmful @ direction
    shift_b = chat_benign @ direction - agent_benign @ direction

    # Does the benign arm move at all? (paired test against zero)
    _, p_benign = paired_ttest_directional(
        chat_benign @ direction, agent_benign @ direction, alternative="two-sided"
    )

    # Interaction: the two shift vectors come from different prompts, so this
    # is a two-sample contrast on within-pair differences. A label-shuffling
    # permutation is the right null here — unlike the within-arm tests, where
    # exchangeability holds within pairs rather than across units.
    rng = np.random.default_rng(seed)
    observed = float(shift_h.mean() - shift_b.mean())
    combined = np.concatenate([shift_h, shift_b])
    n_h = len(shift_h)

    idx = np.argsort(rng.random((n_permutations, len(combined))), axis=1)
    permuted = combined[idx]
    null = permuted[:, :n_h].mean(axis=1) - permuted[:, n_h:].mean(axis=1)
    p_inter = float((np.abs(null) >= abs(observed)).mean())

    d_inter = pooled_cohens_d(shift_h, shift_b)

    # Bootstrap the interaction, resampling each arm independently because the
    # arms are independent groups.
    bh = rng.integers(0, n_h, size=(n_boot, n_h))
    bb = rng.integers(0, len(shift_b), size=(n_boot, len(shift_b)))
    boot = shift_h[bh].mean(axis=1) - shift_b[bb].mean(axis=1)

    dp_h, dp_b = float(shift_h.mean()), float(shift_b.mean())
    common = float(dp_b / dp_h) if abs(dp_h) > 1e-12 else float("nan")

    return SpecificityResult(
        layer_idx=layer_idx,
        n_harmful=len(shift_h),
        n_benign=len(shift_b),
        delta_p_harmful=dp_h,
        delta_p_benign=dp_b,
        interaction=observed,
        benign_shift_p=float(p_benign),
        interaction_p=p_inter,
        interaction_cohens_d=d_inter,
        interaction_ci_lower=float(np.percentile(boot, 2.5)),
        interaction_ci_upper=float(np.percentile(boot, 97.5)),
        common_shift_fraction=common,
    )


# ============================================================
# 2. SCALE-INVARIANT RE-EXPRESSION
# ============================================================

def format_effect_scale(
    chat_harmful: np.ndarray,
    agent_harmful: np.ndarray,
    chat_benign: np.ndarray,
    agent_benign: np.ndarray,
    direction: np.ndarray,
    layer_idx: int = -1,
) -> ScaleResult:
    """
    Express the format effect in raw, standardised and rank units.

    The three disagree whenever the agentic format changes the scale of the
    projection, and the disagreement is the finding: it says how much of the
    headline number is a change of units.
    """
    ph_c, ph_a = chat_harmful @ direction, agent_harmful @ direction
    pb_c, pb_a = chat_benign @ direction, agent_benign @ direction

    sep_c = float(ph_c.mean() - pb_c.mean())
    sep_a = float(ph_a.mean() - pb_a.mean())

    sd_c = float(np.sqrt((ph_c.std(ddof=1) ** 2 + pb_c.std(ddof=1) ** 2) / 2))
    sd_a = float(np.sqrt((ph_a.std(ddof=1) ** 2 + pb_a.std(ddof=1) ** 2) / 2))

    d_c = sep_c / sd_c if sd_c > 1e-12 else 0.0
    d_a = sep_a / sd_a if sd_a > 1e-12 else 0.0

    y_c = np.r_[np.ones(len(ph_c)), np.zeros(len(pb_c))]
    y_a = np.r_[np.ones(len(ph_a)), np.zeros(len(pb_a))]
    auroc_c = float(roc_auc_score(y_c, np.r_[ph_c, pb_c]))
    auroc_a = float(roc_auc_score(y_a, np.r_[ph_a, pb_a]))

    return ScaleResult(
        layer_idx=layer_idx,
        separation_chat=sep_c,
        separation_agent=sep_a,
        separation_loss_raw=float(1.0 - sep_a / sep_c) if abs(sep_c) > 1e-12 else float("nan"),
        pooled_sd_chat=sd_c,
        pooled_sd_agent=sd_a,
        cohens_d_chat=float(d_c),
        cohens_d_agent=float(d_a),
        separation_loss_standardised=float(1.0 - d_a / d_c) if abs(d_c) > 1e-12 else float("nan"),
        auroc_chat=auroc_c,
        auroc_agent=auroc_a,
        auroc_loss=float(auroc_c - auroc_a),
        scale_contraction=float(sd_a / sd_c) if sd_c > 1e-12 else float("nan"),
    )


# ============================================================
# 3. DETECTION CAPABILITY BY EXPLICITNESS STRATUM
# ============================================================

def detection_by_stratum(
    strata_harmful: List[str],
    strata_benign: List[str],
    chat_harmful: np.ndarray,
    agent_harmful: np.ndarray,
    chat_benign: np.ndarray,
    agent_benign: np.ndarray,
    direction: np.ndarray,
    min_per_class: int = 4,
) -> List[StratumDetection]:
    """
    AUROC and standardised separation per explicitness stratum, per format.

    The fourth specific objective asks whether DETECTION CAPABILITY holds as
    harmful intent becomes less explicit. The methodology chapter defines
    detection capability as AUROC, and argues explicitly that DeltaP and AUROC
    answer different questions. The stratified analysis currently reports
    DeltaP per stratum only, which measures intensity, not detection — so the
    objective is not yet answered by the code that claims to answer it.

    AUROC needs both classes, so the benign arm is stratified too. The corpus
    labels benign prompts with the explicitness of the harmful prompt they were
    built from, which is what makes the within-stratum contrast meaningful.

    Args:
        strata_harmful / strata_benign: per-row stratum labels, aligned with
            the corresponding activation arrays.
        min_per_class: strata with fewer rows than this in either class are
            skipped; AUROC on a handful of points is noise.

    Returns:
        One StratumDetection per stratum with enough data, ordered by name.
    """
    strata_harmful = list(strata_harmful)
    strata_benign = list(strata_benign)

    if len(strata_harmful) != len(chat_harmful):
        raise ValueError("harmful stratum labels are not aligned with activations")
    if len(strata_benign) != len(chat_benign):
        raise ValueError("benign stratum labels are not aligned with activations")

    ph_c, ph_a = chat_harmful @ direction, agent_harmful @ direction
    pb_c, pb_a = chat_benign @ direction, agent_benign @ direction

    out: List[StratumDetection] = []
    for stratum in sorted(set(strata_harmful)):
        ih = np.array([i for i, s in enumerate(strata_harmful) if s == stratum])
        ib = np.array([i for i, s in enumerate(strata_benign) if s == stratum])
        if len(ih) < min_per_class or len(ib) < min_per_class:
            continue

        y = np.r_[np.ones(len(ih)), np.zeros(len(ib))]
        auroc_c = float(roc_auc_score(y, np.r_[ph_c[ih], pb_c[ib]]))
        auroc_a = float(roc_auc_score(y, np.r_[ph_a[ih], pb_a[ib]]))

        sd_c = np.sqrt((ph_c[ih].std(ddof=1) ** 2 + pb_c[ib].std(ddof=1) ** 2) / 2)
        sd_a = np.sqrt((ph_a[ih].std(ddof=1) ** 2 + pb_a[ib].std(ddof=1) ** 2) / 2)
        d_c = (ph_c[ih].mean() - pb_c[ib].mean()) / sd_c if sd_c > 1e-12 else 0.0
        d_a = (ph_a[ih].mean() - pb_a[ib].mean()) / sd_a if sd_a > 1e-12 else 0.0

        out.append(StratumDetection(
            stratum=stratum,
            n_harmful=len(ih),
            n_benign=len(ib),
            auroc_chat=auroc_c,
            auroc_agent=auroc_a,
            auroc_loss=auroc_c - auroc_a,
            cohens_d_chat=float(d_c),
            cohens_d_agent=float(d_a),
            separation_loss_standardised=(
                float(1.0 - d_a / d_c) if abs(d_c) > 1e-12 else float("nan")
            ),
        ))

    return out


# ============================================================
# 4. REPORTING
# ============================================================

def format_specificity_report(res: SpecificityResult) -> str:
    """Human-readable difference-in-differences report."""
    lines = [
        "=" * 72,
        f"FORMAT EFFECT SPECIFICITY  (layer {res.layer_idx})  "
        f"[benign control / diff-in-diff]",
        "=" * 72,
        f"  DeltaP harmful (the headline effect) : {res.delta_p_harmful:+.4f}  "
        f"(n={res.n_harmful})",
        f"  DeltaP benign  (the control)         : {res.delta_p_benign:+.4f}  "
        f"(n={res.n_benign})",
        f"  benign arm moves? p                  : {res.benign_shift_p:.4f}",
        "-" * 72,
        f"  INTERACTION (harmful - benign)       : {res.interaction:+.4f}",
        f"  permutation p                        : {res.interaction_p:.4f}",
        f"  Cohen d (pooled)                     : {res.interaction_cohens_d:+.3f}",
        f"  95% CI                               : "
        f"[{res.interaction_ci_lower:+.4f}, {res.interaction_ci_upper:+.4f}]",
        f"  share of the effect common to benign : "
        f"{res.common_shift_fraction:+.1%}",
        "-" * 72,
    ]
    if res.is_specific:
        lines += [
            "  VERDICT: the shift is SPECIFIC to harmful requests. A rigid",
            "           translation of the whole representation is ruled out,",
            "           so DeltaP cannot be dismissed as an offset.",
        ]
    elif res.interaction_p >= 0.05:
        lines += [
            "  VERDICT: no detectable interaction. The agentic format displaces",
            "           harmful and benign representations ALIKE, which is a",
            "           change of origin, not a weakening of refusal. DeltaP",
            "           must NOT be read as loss of safety representation.",
        ]
    else:
        lines += [
            "  VERDICT: interaction runs OPPOSITE to the hypothesis — the",
            "           direction responds more to harm under the agentic format.",
        ]
    lines.append("=" * 72)
    return "\n".join(lines)


def format_scale_report(res: ScaleResult) -> str:
    """Human-readable scale-invariance report."""
    lines = [
        "=" * 72,
        f"FORMAT EFFECT IN SCALE-INVARIANT UNITS  (layer {res.layer_idx})",
        "=" * 72,
        f"{'':<34}{'chat':>12}{'agent':>12}{'loss':>13}",
        "-" * 72,
        f"{'separation (raw units)':<34}{res.separation_chat:>12.4f}"
        f"{res.separation_agent:>12.4f}{res.separation_loss_raw:>12.1%}",
        f"{'pooled SD (raw units)':<34}{res.pooled_sd_chat:>12.4f}"
        f"{res.pooled_sd_agent:>12.4f}{'':>13}",
        f"{'separation (Cohen d)':<34}{res.cohens_d_chat:>12.4f}"
        f"{res.cohens_d_agent:>12.4f}{res.separation_loss_standardised:>12.1%}",
        f"{'AUROC':<34}{res.auroc_chat:>12.4f}"
        f"{res.auroc_agent:>12.4f}{res.auroc_loss:>12.1%}",
        "-" * 72,
        f"  scale contraction (SD_agent / SD_chat): {res.scale_contraction:.3f}",
    ]
    if res.raw_loss_is_inflated:
        lines += [
            "",
            "  WARNING: the raw loss materially exceeds the standardised one.",
            "           The agentic format compressed the projection scale, so",
            "           part of the headline DeltaP is a change of units and not",
            "           a loss of separability. Report the standardised figure",
            "           as the effect and the raw one as its scale-dependent",
            "           counterpart, exactly as the chapter already requires",
            "           when comparing across layers.",
        ]
    at_ceiling = res.auroc_chat > 0.97 and res.auroc_agent > 0.97
    if at_ceiling and abs(res.separation_loss_standardised) > 0.02:
        lines += [
            "",
            "  NOTE: AUROC is at ceiling in BOTH formats. It certifies that",
            "        detection survives, but it cannot resolve the "
            f"{abs(res.separation_loss_standardised):.0%} loss of margin the",
            "        standardised separation reports. Do not read a flat AUROC",
            "        as 'the mechanism is unaffected' — read it as 'the margin",
            "        shrank without crossing the decision boundary'.",
        ]
    lines.append("=" * 72)
    return "\n".join(lines)


def format_stratum_report(results: List[StratumDetection]) -> str:
    """Human-readable per-stratum detection report."""
    lines = [
        "=" * 72,
        "DETECTION CAPABILITY BY EXPLICITNESS  [objective 4: AUROC, not DeltaP]",
        "=" * 72,
        f"{'stratum':<14}{'n_h':>5}{'n_b':>5}{'AUROC_chat':>12}{'AUROC_ag':>11}"
        f"{'d_chat':>9}{'d_agent':>9}{'d loss':>9}",
        "-" * 72,
    ]
    for r in results:
        lines.append(
            f"{r.stratum:<14}{r.n_harmful:>5}{r.n_benign:>5}{r.auroc_chat:>12.4f}"
            f"{r.auroc_agent:>11.4f}{r.cohens_d_chat:>9.3f}{r.cohens_d_agent:>9.3f}"
            f"{r.separation_loss_standardised:>8.1%}"
        )
    lines.append("-" * 72)
    if results:
        worst = max(results, key=lambda r: r.auroc_loss)
        lines += [
            f"  Detection degrades most in '{worst.stratum}' "
            f"(AUROC {worst.auroc_chat:.3f} -> {worst.auroc_agent:.3f}).",
        ]
        if all(r.auroc_agent > 0.9 for r in results):
            lines += [
                "  Detection holds above 0.90 in every stratum: the direction",
                "  still separates harm from benignity even when the intent is",
                "  covert. The objective's question is answered in the",
                "  affirmative, for this corpus.",
            ]
    lines.append("=" * 72)
    return "\n".join(lines)
