"""
Robust (bias-corrected) estimators for the agentic safety probe.

This module addresses three inference problems in the original pipeline that
inflate the reported quantities. Each corrected estimator is paired with the
naive one so the magnitude of the bias can be reported, not just removed.

PROBLEM 1 — Circularity in DeltaP (Observation 2)
    d_chat is estimated from chat_harmful, and chat_harmful is then projected
    onto it. In the d >> n regime the noise in the sample centroid enters the
    direction and is recovered on projection, biasing the chat term upward.
    The agent term carries no such bias, so DeltaP is inflated.
    FIX: cross-fitting. Estimate d on K-1 folds, project the held-out fold.

PROBLEM 2 — No train/test split for w_agent and the monitor (Observation 3)
    With N=84 in d=8192, Cover's theorem guarantees linear separability for
    ANY labelling. In-sample AUROC = 1.0 is a geometric certainty, not
    evidence. Threshold calibration on the evaluation set has the same defect.
    FIX: stratified K-fold. Fit and calibrate on train, score on test.

PROBLEM 3 — Unquantified attenuation in the rotation angle (Observation 9)
    cos(w_agent, d_chat) is attenuated by estimation noise in w_agent, so the
    reported angle is an upper bound. Without a reliability estimate the
    magnitude cannot be interpreted.
    FIX: report inter-fold cos(w_i, w_j) as the reliability ceiling.

The module also provides single canonical implementations of the paired
statistics, replacing the inconsistent variants in metrics.py,
refusal_direction.py and stratified_analysis.py (Observations 5, 6, 7, 8).

All estimators preserve the paired structure of the design: fold assignment
and bootstrap resampling operate on PROMPT indices, so a prompt's chat and
agent observations always travel together.
"""

from __future__ import annotations

import numpy as np
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from scipy import stats
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score, roc_auc_score
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler


# Minimum split-half reliability at which the attenuation correction is
# reported. The correction divides by sqrt(reliability), so this floor caps
# the noise amplification at 2x. Below it the corrected angle is not
# interpretable and the estimators return nan rather than a plausible-looking
# artefact. Value chosen so that the correction never inflates by more than a
# factor of two, matching the conventional psychometric guidance that
# correction for attenuation becomes unstable at low reliability.
MIN_RELIABILITY_FOR_CORRECTION = 0.25


# ============================================================
# RESULT CONTAINERS
# ============================================================

@dataclass
class PairedTestResult:
    """Outcome of the paired inference suite on one pair of projection vectors."""
    n_pairs: int
    delta_p: float
    mean_a: float
    mean_b: float
    # Paired t-test (sign-aware one-sided)
    t_statistic: float
    p_value_ttest: float
    alternative: str
    # Sign-flip permutation test
    p_value_permutation: float
    permutation_z: float
    n_permutations: int
    p_value_floor: float          # smallest p this permutation budget can express
    # Effect sizes (both, ddof=1)
    cohens_d_paired: float
    cohens_d_pooled: float
    implied_pair_correlation: float
    # Paired bootstrap
    ci_lower: float
    ci_upper: float
    # Distribution-free sign summary
    n_decreasing: int
    sign_test_p: float


@dataclass
class CrossFittedGapResult:
    """Cross-fitted DeltaP with the naive estimate retained for comparison."""
    layer_idx: int
    n_folds: int
    delta_p_naive: float
    delta_p_crossfit: float
    bias_estimate: float          # naive - crossfit
    bias_ratio: float             # bias / |crossfit|, inf when crossfit ~ 0
    naive_stats: PairedTestResult
    crossfit_stats: PairedTestResult
    proj_chat_oof: np.ndarray = field(repr=False, default=None)
    proj_agent_oof: np.ndarray = field(repr=False, default=None)


@dataclass
class CrossValidatedDirectionResult:
    """Out-of-fold evaluation of w_agent plus its reliability ceiling."""
    layer_idx: int
    n_folds: int
    auroc_in_sample: float        # the inflated number the old pipeline reported
    auroc_oof_mean: float
    auroc_oof_std: float
    auroc_oof_folds: List[float]
    # Alignment with d_chat
    cosine_with_d_chat_mean: float
    cosine_with_d_chat_std: float
    angle_deg_mean: float
    # Reliability from DISJOINT split-halves (see note in the estimator)
    split_half_reliability: float
    split_half_reliability_std: float
    attenuation_factor: float          # sqrt(reliability); 1.0 = no attenuation
    cosine_disattenuated: float        # measured / attenuation_factor, clipped
    angle_deg_disattenuated: float
    # Inter-fold cosine, retained for diagnosis only: it is INFLATED because
    # K-fold training sets overlap, so it must not be used as the ceiling.
    inter_fold_cosine_mean: float
    inter_fold_cosine_std: float
    # Chance scale in this dimension
    chance_cosine_sd: float
    cosine_in_chance_sd: float
    w_agent_full: np.ndarray = field(repr=False, default=None)


@dataclass
class CrossValidatedMonitorResult:
    """Out-of-fold monitor metrics with the threshold calibrated on train only."""
    layer_idx: int
    n_folds: int
    precision_oof: float
    recall_oof: float
    f1_oof: float
    fpr_oof: float
    thresholds_per_fold: List[float]
    f1_in_sample: float           # the inflated number the old pipeline reported
    n_harmful: int
    n_benign: int


# ============================================================
# 1. CANONICAL PAIRED STATISTICS
#    Single implementation; replaces the divergent copies elsewhere.
# ============================================================

def paired_cohens_d(a: np.ndarray, b: np.ndarray) -> float:
    """
    Standardised mean difference for paired samples (Cohen's d_z).

    d_z = mean(a - b) / sd(a - b), with sd using ddof=1.

    Note this is NOT interchangeable with the pooled variant; d_z answers
    "how consistent is the within-pair change", not "how separated are the
    two distributions". Cohen's conventional benchmarks were set for the
    latter. Report both.
    """
    diff = np.asarray(a) - np.asarray(b)
    sd = diff.std(ddof=1)
    return float(diff.mean() / sd) if sd > 1e-12 else 0.0


def pooled_cohens_d(a: np.ndarray, b: np.ndarray) -> float:
    """Standardised mean difference treating the samples as independent (d_av)."""
    a, b = np.asarray(a), np.asarray(b)
    pooled_sd = np.sqrt((a.std(ddof=1) ** 2 + b.std(ddof=1) ** 2) / 2)
    return float((a.mean() - b.mean()) / pooled_sd) if pooled_sd > 1e-12 else 0.0


def implied_pair_correlation(d_paired: float, d_pooled: float) -> float:
    """
    Recover the within-pair correlation implied by the two effect sizes.

    From d_paired = d_pooled / sqrt(2(1-r)):
        r = 1 - (1/2)(d_pooled / d_paired)^2

    A high r confirms the pairing did its job. Returns nan when d_paired is
    ~0, where the relation is undefined.
    """
    if abs(d_paired) < 1e-12:
        return float("nan")
    return float(1.0 - 0.5 * (d_pooled / d_paired) ** 2)


def paired_ttest_directional(
    a: np.ndarray,
    b: np.ndarray,
    alternative: str = "greater",
) -> Tuple[float, float]:
    """
    Paired t-test with a SIGN-AWARE one-sided p-value (Observation 8).

    The original code computed p_one_sided = p_two_sided / 2 unconditionally.
    That identity only holds when the observed effect points the way H1
    predicts; otherwise the correct value is 1 - p_two_sided/2, and the naive
    halving reports a small p for an effect in the WRONG direction.

    Args:
        a, b: paired observations. alternative='greater' tests mean(a) > mean(b).

    Returns:
        (t_statistic, one_sided_p_value)
    """
    if alternative not in ("greater", "less", "two-sided"):
        raise ValueError(f"alternative must be greater/less/two-sided, got {alternative}")

    t_stat, p_two = stats.ttest_rel(a, b)
    t_stat = float(t_stat)

    if alternative == "two-sided":
        return t_stat, float(p_two)

    # Halve only when the sign agrees with the alternative; otherwise complement.
    sign_agrees = (t_stat > 0) if alternative == "greater" else (t_stat < 0)
    p_one = p_two / 2.0 if sign_agrees else 1.0 - p_two / 2.0
    return t_stat, float(p_one)


def paired_permutation_test(
    a: np.ndarray,
    b: np.ndarray,
    n_permutations: int = 10000,
    alternative: str = "greater",
    seed: int = 42,
) -> Dict[str, float]:
    """
    Sign-flip permutation test for paired data (Observation 5).

    Under H0 the two condition labels are exchangeable WITHIN each pair, so
    the null is generated by independently flipping each pair's sign. This is
    the correct null for this design. A global shuffle of the concatenated
    samples — used elsewhere in the original pipeline — assumes exchangeability
    ACROSS units, which the paired design violates; it discards the within-pair
    correlation and loses power.

    Reports p_value_floor = 1/n_permutations. An empirical p of 0.0 must be
    read as "p < floor", never as exactly zero.
    """
    a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
    if len(a) != len(b):
        raise ValueError("paired test requires equal-length inputs")

    rng = np.random.default_rng(seed)
    diff = a - b
    n = len(diff)
    observed = float(diff.mean())

    # Vectorised sign-flip: (n_permutations, n) matrix of +/-1
    signs = rng.choice(np.array([-1.0, 1.0]), size=(n_permutations, n))
    null = (signs * diff).mean(axis=1)

    if alternative == "greater":
        p = float((null >= observed).mean())
    elif alternative == "less":
        p = float((null <= observed).mean())
    else:
        p = float((np.abs(null) >= abs(observed)).mean())

    null_sd = null.std(ddof=1)
    z = float((observed - null.mean()) / null_sd) if null_sd > 1e-12 else 0.0

    return {
        "observed": observed,
        "p_value": p,
        "z_score": z,
        "null_mean": float(null.mean()),
        "null_sd": float(null_sd),
        "n_permutations": n_permutations,
        "p_value_floor": 1.0 / n_permutations,
    }


def paired_bootstrap_ci(
    a: np.ndarray,
    b: np.ndarray,
    n_boot: int = 10000,
    ci_level: float = 0.95,
    seed: int = 42,
    bca: bool = True,
) -> Dict[str, float]:
    """
    Bootstrap CI for the paired mean difference (Observation 6).

    A SINGLE index vector is drawn and applied to both conditions, preserving
    the pairing. Drawing independent indices per condition — as the stratified
    and decomposition routines did — estimates the variance of a difference
    between independent groups instead, yielding intervals wider than the
    design warrants.

    Two intervals are returned:

      PERCENTILE  the 2.5th and 97.5th percentiles of the resampled statistic.
                  Reported as ci_lower/ci_upper, unchanged from before.

      BCa         bias-corrected and accelerated. The percentile interval is
                  only first-order accurate and mis-covers when the bootstrap
                  distribution is biased or skewed, which is the common case at
                  n ~ 40. BCa shifts the percentiles by z0 (median bias) and
                  corrects for a variance that changes with the estimate
                  (acceleration, from the jackknife). It is second-order
                  accurate and transformation-respecting.

    `excludes_zero` states the decision the interval exists to support, so no
    caller has to re-derive it from two floats.

    Default n_boot is 10,000: with 1,000 resamples each 95% tail contains only
    ~25 values, so the endpoints carry visible Monte-Carlo noise and shift
    between seeds.
    """
    a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
    if len(a) != len(b):
        raise ValueError("paired bootstrap requires equal-length inputs")

    rng = np.random.default_rng(seed)
    n = len(a)
    diff = a - b                                     # the paired statistic
    observed = float(diff.mean())

    idx = rng.integers(0, n, size=(n_boot, n))       # shared across conditions
    boot = diff[idx].mean(axis=1)

    alpha = 1.0 - ci_level
    lo_pct, hi_pct = 100 * alpha / 2, 100 * (1 - alpha / 2)
    ci_lower = float(np.percentile(boot, lo_pct))
    ci_upper = float(np.percentile(boot, hi_pct))

    # Two-sided bootstrap p-value: how much of the resampled mass sits on the
    # far side of zero, doubled. Floored at 1/n_boot — a value of 0 means
    # "below the resolution of this budget", never exactly zero.
    prop_below = float((boot <= 0.0).mean())
    p_boot = 2.0 * min(prop_below, 1.0 - prop_below)
    p_boot = float(min(1.0, max(p_boot, 1.0 / n_boot)))

    out = {
        "mean": float(boot.mean()),
        "observed": observed,
        "ci_lower": ci_lower,
        "ci_upper": ci_upper,
        "std": float(boot.std(ddof=1)),
        "excludes_zero": bool(ci_lower > 0.0 or ci_upper < 0.0),
        "p_bootstrap_two_sided": p_boot,
        "n_boot": int(n_boot),
        "ci_level": float(ci_level),
        "ci_lower_bca": float("nan"),
        "ci_upper_bca": float("nan"),
        "excludes_zero_bca": None,
        "bias_correction_z0": float("nan"),
        "acceleration": float("nan"),
    }

    if not bca or n < 3:
        return out

    # ---- BCa ----
    # z0: median bias, from the share of resamples below the observed value.
    prop_less = float((boot < observed).mean())
    if prop_less <= 0.0 or prop_less >= 1.0:
        return out                                   # degenerate; percentile only
    z0 = float(stats.norm.ppf(prop_less))

    # Acceleration from the jackknife over PROMPTS (the resampling unit), so
    # the pairing is respected here too. For a mean, the leave-one-out values
    # are available in closed form.
    total = diff.sum()
    jack = (total - diff) / (n - 1)                   # leave-one-out means
    jack_mean = jack.mean()
    dev = jack_mean - jack
    denom = 6.0 * (dev ** 2).sum() ** 1.5
    if denom < 1e-300:
        return out
    acc = float((dev ** 3).sum() / denom)

    z_lo, z_hi = stats.norm.ppf(alpha / 2), stats.norm.ppf(1 - alpha / 2)
    adj_lo = z0 + (z0 + z_lo) / (1 - acc * (z0 + z_lo))
    adj_hi = z0 + (z0 + z_hi) / (1 - acc * (z0 + z_hi))
    p_lo = float(np.clip(stats.norm.cdf(adj_lo) * 100, 0.0, 100.0))
    p_hi = float(np.clip(stats.norm.cdf(adj_hi) * 100, 0.0, 100.0))

    bca_lower = float(np.percentile(boot, p_lo))
    bca_upper = float(np.percentile(boot, p_hi))

    out.update({
        "ci_lower_bca": bca_lower,
        "ci_upper_bca": bca_upper,
        "excludes_zero_bca": bool(bca_lower > 0.0 or bca_upper < 0.0),
        "bias_correction_z0": z0,
        "acceleration": acc,
    })
    return out


def paired_sign_test(a: np.ndarray, b: np.ndarray) -> Tuple[int, float]:
    """
    Exact sign test: how many pairs decrease, and how surprising is that.

    Fully distribution-free and immune to every bias discussed in this module,
    because it uses only the sign of each within-pair difference and never the
    magnitude. When the direction of an effect is contested but its magnitude
    is disputed, this is the statistic that survives.

    Returns:
        (n_decreasing, two_sided_exact_binomial_p)
    """
    diff = np.asarray(a) - np.asarray(b)
    nonzero = diff[diff != 0]
    n_dec = int((nonzero > 0).sum())
    n = len(nonzero)
    if n == 0:
        return 0, 1.0
    p = float(stats.binomtest(n_dec, n, 0.5, alternative="two-sided").pvalue)
    return n_dec, p


def run_paired_suite(
    a: np.ndarray,
    b: np.ndarray,
    n_permutations: int = 10000,
    n_boot: int = 10000,
    alternative: str = "greater",
    seed: int = 42,
) -> PairedTestResult:
    """Run the full corrected paired inference suite on two projection vectors."""
    a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)

    t_stat, p_t = paired_ttest_directional(a, b, alternative=alternative)
    perm = paired_permutation_test(a, b, n_permutations, alternative, seed)
    boot = paired_bootstrap_ci(a, b, n_boot, 0.95, seed)
    d_par = paired_cohens_d(a, b)
    d_pool = pooled_cohens_d(a, b)
    n_dec, p_sign = paired_sign_test(a, b)

    return PairedTestResult(
        n_pairs=len(a),
        delta_p=float(a.mean() - b.mean()),
        mean_a=float(a.mean()),
        mean_b=float(b.mean()),
        t_statistic=t_stat,
        p_value_ttest=p_t,
        alternative=alternative,
        p_value_permutation=perm["p_value"],
        permutation_z=perm["z_score"],
        n_permutations=n_permutations,
        p_value_floor=perm["p_value_floor"],
        cohens_d_paired=d_par,
        cohens_d_pooled=d_pool,
        implied_pair_correlation=implied_pair_correlation(d_par, d_pool),
        ci_lower=boot["ci_lower"],
        ci_upper=boot["ci_upper"],
        n_decreasing=n_dec,
        sign_test_p=p_sign,
    )


# ============================================================
# 2. CROSS-FITTED PROJECTION GAP  (Observation 2)
# ============================================================

def _diff_in_means_direction(harmful: np.ndarray, benign: np.ndarray) -> np.ndarray:
    """Normalised difference-in-means direction. Raises on a degenerate contrast."""
    direction = harmful.mean(axis=0) - benign.mean(axis=0)
    norm = np.linalg.norm(direction)
    if norm < 1e-10:
        raise ValueError("Degenerate contrast: harmful and benign centroids coincide.")
    return direction / norm


def cross_fitted_projection_gap(
    chat_harmful: np.ndarray,
    chat_benign: np.ndarray,
    agent_harmful: np.ndarray,
    layer_idx: int = -1,
    n_folds: int = 5,
    n_permutations: int = 10000,
    n_boot: int = 10000,
    seed: int = 42,
) -> CrossFittedGapResult:
    """
    Cross-fitted estimate of DeltaP, removing the own-sample bias.

    The naive pipeline estimates d_chat from chat_harmful and chat_benign, then
    projects chat_harmful onto it. Because d = 8192 >> n = 42, the sample
    centroid mu_H carries a substantial noise component that propagates into
    the direction; projecting mu_H back onto that direction recovers part of
    it. The chat term is therefore inflated. The agent condition never enters
    the estimation, so it carries no matching inflation, and DeltaP absorbs the
    whole difference.

    Cross-fitting breaks the circularity: for each fold k the direction is
    estimated WITHOUT fold k, and only fold k is projected. Every projection is
    out-of-sample with respect to the direction that produced it.

    Pairing is preserved: folds are assigned over PROMPT indices, and a
    prompt's chat and agent activations are always projected onto the same
    held-out direction d_k.

    Args:
        chat_harmful:  (n, hidden_dim) chat-format harmful activations.
        chat_benign:   (m, hidden_dim) chat-format benign activations.
        agent_harmful: (n, hidden_dim) agent-format harmful activations, paired
                       row-wise with chat_harmful.
        layer_idx:     recorded for reporting only.
        n_folds:       K in K-fold cross-fitting.

    Returns:
        CrossFittedGapResult carrying naive and cross-fitted estimates, the
        bias, and the full paired inference suite for each.
    """
    chat_harmful = np.asarray(chat_harmful, dtype=np.float64)
    chat_benign = np.asarray(chat_benign, dtype=np.float64)
    agent_harmful = np.asarray(agent_harmful, dtype=np.float64)

    n = len(chat_harmful)
    if len(agent_harmful) != n:
        raise ValueError(
            f"chat_harmful ({n}) and agent_harmful ({len(agent_harmful)}) must be "
            "paired row-wise."
        )
    if n_folds < 2 or n_folds > n:
        raise ValueError(f"n_folds must be in [2, {n}], got {n_folds}")

    # ---- Naive (in-sample) estimate: what the original pipeline reports ----
    d_full = _diff_in_means_direction(chat_harmful, chat_benign)
    proj_chat_naive = chat_harmful @ d_full
    proj_agent_naive = agent_harmful @ d_full
    naive_stats = run_paired_suite(
        proj_chat_naive, proj_agent_naive, n_permutations, n_boot, "greater", seed
    )

    # ---- Cross-fitted estimate ----
    rng = np.random.default_rng(seed)
    order = rng.permutation(n)
    folds = np.array_split(order, n_folds)

    # Benign rows are folded independently; they may differ in count from n.
    m = len(chat_benign)
    order_b = rng.permutation(m)
    folds_b = np.array_split(order_b, n_folds)

    proj_chat_oof = np.empty(n)
    proj_agent_oof = np.empty(n)

    for k in range(n_folds):
        test_idx = folds[k]
        train_idx = np.concatenate([folds[j] for j in range(n_folds) if j != k])
        train_idx_b = np.concatenate([folds_b[j] for j in range(n_folds) if j != k])

        d_k = _diff_in_means_direction(
            chat_harmful[train_idx], chat_benign[train_idx_b]
        )
        # Both conditions of a held-out prompt use the SAME direction: pairing intact.
        proj_chat_oof[test_idx] = chat_harmful[test_idx] @ d_k
        proj_agent_oof[test_idx] = agent_harmful[test_idx] @ d_k

    crossfit_stats = run_paired_suite(
        proj_chat_oof, proj_agent_oof, n_permutations, n_boot, "greater", seed
    )

    bias = naive_stats.delta_p - crossfit_stats.delta_p
    denom = abs(crossfit_stats.delta_p)
    bias_ratio = float(bias / denom) if denom > 1e-12 else float("inf")

    return CrossFittedGapResult(
        layer_idx=layer_idx,
        n_folds=n_folds,
        delta_p_naive=naive_stats.delta_p,
        delta_p_crossfit=crossfit_stats.delta_p,
        bias_estimate=float(bias),
        bias_ratio=bias_ratio,
        naive_stats=naive_stats,
        crossfit_stats=crossfit_stats,
        proj_chat_oof=proj_chat_oof,
        proj_agent_oof=proj_agent_oof,
    )


# ============================================================
# 3. CROSS-VALIDATED AGENT DIRECTION  (Observations 3 and 9)
# ============================================================

def _fit_agent_direction(X: np.ndarray, y: np.ndarray, C: float = 1.0,
                         seed: int = 42) -> np.ndarray:
    """
    Fit a logistic probe and return its normal in the ORIGINAL activation space.

    The probe trains on standardised features, so the raw coefficient lives in
    the scaled space. Since z_j = (a_j - mu_j)/s_j, the hyperplane normal in
    the original space is w_j / s_j (element-wise). Skipping this rescaling
    would make any cosine against d_chat meaningless, because the two vectors
    would inhabit different metric spaces.
    """
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    clf = LogisticRegression(max_iter=1000, C=C, solver="lbfgs", random_state=seed)
    clf.fit(X_scaled, y)

    w = clf.coef_[0] / scaler.scale_
    norm = np.linalg.norm(w)
    if norm < 1e-12:
        raise ValueError("Probe returned a degenerate (zero-norm) direction.")
    return w / norm


def _split_half_reliability(
    X: np.ndarray,
    y: np.ndarray,
    C: float = 1.0,
    n_repeats: int = 20,
    seed: int = 42,
) -> Tuple[float, float]:
    """
    Reproducibility of w_agent measured on DISJOINT halves of the data.

    Why not the inter-fold cosine: in K-fold cross-validation the training
    partitions overlap (with K=5, any two share 60% of their samples), so the
    two fitted directions share a large part of their noise. Their agreement
    therefore overstates reproducibility, sometimes drastically.

    Splitting into two halves with NO shared samples makes the noise
    components independent, which is the condition under which

        cos(w_1, w_2) = b^2

    holds for w = b * w_true + noise. That identity is what licenses the
    attenuation correction, so the disjointness is not a refinement but a
    requirement.

    Returns:
        (mean reliability over repeats, sd over repeats)
    """
    rng = np.random.default_rng(seed)
    n = len(y)
    cosines: List[float] = []

    for _ in range(n_repeats):
        # Stratified disjoint halves: split each class separately so both
        # halves keep both classes.
        idx_pos = rng.permutation(np.flatnonzero(y == 1))
        idx_neg = rng.permutation(np.flatnonzero(y == 0))
        half_a = np.concatenate([idx_pos[: len(idx_pos) // 2],
                                 idx_neg[: len(idx_neg) // 2]])
        half_b = np.concatenate([idx_pos[len(idx_pos) // 2:],
                                 idx_neg[len(idx_neg) // 2:]])

        if len(np.unique(y[half_a])) < 2 or len(np.unique(y[half_b])) < 2:
            continue
        try:
            w_a = _fit_agent_direction(X[half_a], y[half_a], C=C, seed=seed)
            w_b = _fit_agent_direction(X[half_b], y[half_b], C=C, seed=seed)
        except ValueError:
            continue
        cosines.append(float(np.dot(w_a, w_b)))

    if not cosines:
        return float("nan"), float("nan")
    return (
        float(np.mean(cosines)),
        float(np.std(cosines, ddof=1)) if len(cosines) > 1 else 0.0,
    )


def cross_validated_agent_direction(
    agent_harmful: np.ndarray,
    agent_benign: np.ndarray,
    d_chat: Optional[np.ndarray] = None,
    layer_idx: int = -1,
    n_folds: int = 5,
    C: float = 1.0,
    seed: int = 42,
) -> CrossValidatedDirectionResult:
    """
    Estimate w_agent with honest out-of-fold evaluation and a reliability ceiling.

    Why the original in-sample AUROC carries no information: with N = 84
    observations in d = 8192 dimensions, Cover's theorem states that N points
    in general position in R^d are linearly separable for ANY labelling when
    N <= d + 1. Perfect in-sample separation is therefore guaranteed a priori
    and would also be obtained from randomly permuted labels. It is a property
    of the geometry, not a finding about the data.

    The inter-fold cosine addresses a separate problem. w_agent estimated from
    84 points in 8192 dimensions is noise-dominated, and in high dimension the
    noise is near-orthogonal to any fixed direction, so cos(w_agent, d_chat) is
    attenuated toward zero and the reported angle is an UPPER BOUND. Comparing
    directions estimated from disjoint folds measures how much of w_agent is
    reproducible at all, which is the ceiling on how precisely its angle with
    d_chat can be known. If two disjoint estimates of w_agent agree only at
    cos = 0.5, a measured cos = 0.36 against d_chat cannot be reported to two
    decimal places.

    Returns:
        CrossValidatedDirectionResult with out-of-fold AUROC per fold, the
        in-sample value for comparison, alignment with d_chat, the inter-fold
        reliability, and the chance scale for this dimensionality.
    """
    agent_harmful = np.asarray(agent_harmful, dtype=np.float64)
    agent_benign = np.asarray(agent_benign, dtype=np.float64)

    X = np.concatenate([agent_harmful, agent_benign], axis=0)
    y = np.concatenate([np.ones(len(agent_harmful)), np.zeros(len(agent_benign))])
    hidden_dim = X.shape[1]

    # ---- In-sample value: the inflated number, kept for explicit comparison ----
    w_full = _fit_agent_direction(X, y, C=C, seed=seed)
    auroc_in_sample = float(roc_auc_score(y, X @ w_full))

    # ---- Out-of-fold evaluation ----
    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=seed)
    fold_dirs: List[np.ndarray] = []
    fold_aurocs: List[float] = []
    fold_cosines: List[float] = []

    for train_idx, test_idx in skf.split(X, y):
        w_k = _fit_agent_direction(X[train_idx], y[train_idx], C=C, seed=seed)
        scores = X[test_idx] @ w_k
        # A fold with a single class present cannot yield an AUROC.
        if len(np.unique(y[test_idx])) > 1:
            fold_aurocs.append(float(roc_auc_score(y[test_idx], scores)))
        fold_dirs.append(w_k)
        if d_chat is not None:
            fold_cosines.append(float(np.dot(w_k, d_chat)))

    # ---- Inter-fold cosine: DIAGNOSTIC ONLY, do not use as the ceiling ----
    # K-fold training sets overlap heavily (with K=5, any two share 60% of
    # their samples), so their noise components are correlated and this
    # quantity is biased upward as a measure of reproducibility.
    inter = [
        float(np.dot(fold_dirs[i], fold_dirs[j]))
        for i in range(len(fold_dirs))
        for j in range(i + 1, len(fold_dirs))
    ]

    # ---- Reliability from DISJOINT split-halves ----
    sh_mean, sh_std = _split_half_reliability(X, y, C=C, seed=seed)

    # Correction for attenuation (Spearman). If the estimate is
    #     w_est = b * w_true + noise,  noise ~ orthogonal
    # then two estimates from DISJOINT data have independent noise, so
    #     cos(w_1, w_2) = b^2      and      cos(w_est, d_chat) = b * cos_true.
    # Hence b = sqrt(reliability), and the true cosine is recovered by
    # dividing the measured one by b.
    attenuation = (
        float(np.sqrt(sh_mean)) if np.isfinite(sh_mean) and sh_mean > 0.0
        else float("nan")
    )

    chance_sd = 1.0 / np.sqrt(hidden_dim)
    cos_mean = float(np.mean(fold_cosines)) if fold_cosines else 0.0

    # GUARD: the correction divides by the attenuation factor, so it amplifies
    # estimation noise by 1/b. Below MIN_RELIABILITY_FOR_CORRECTION the
    # amplification exceeds 2x and the "corrected" value is numerically
    # meaningless - it can exceed 1 and clip to a spurious 0 deg. Refusing to
    # report is the correct behaviour: a direction this irreproducible does
    # not have a recoverable angle at this sample size. Returning nan forces
    # that fact to surface instead of hiding behind a plausible number.
    if np.isfinite(attenuation) and sh_mean >= MIN_RELIABILITY_FOR_CORRECTION:
        cos_disatt = float(np.clip(cos_mean / attenuation, -1.0, 1.0))
    else:
        cos_disatt = float("nan")

    return CrossValidatedDirectionResult(
        layer_idx=layer_idx,
        n_folds=n_folds,
        auroc_in_sample=auroc_in_sample,
        auroc_oof_mean=float(np.mean(fold_aurocs)) if fold_aurocs else float("nan"),
        auroc_oof_std=float(np.std(fold_aurocs, ddof=1)) if len(fold_aurocs) > 1 else 0.0,
        auroc_oof_folds=fold_aurocs,
        cosine_with_d_chat_mean=cos_mean,
        cosine_with_d_chat_std=(
            float(np.std(fold_cosines, ddof=1)) if len(fold_cosines) > 1 else 0.0
        ),
        angle_deg_mean=float(np.degrees(np.arccos(np.clip(cos_mean, -1.0, 1.0)))),
        split_half_reliability=sh_mean,
        split_half_reliability_std=sh_std,
        attenuation_factor=attenuation,
        cosine_disattenuated=cos_disatt,
        angle_deg_disattenuated=(
            float(np.degrees(np.arccos(cos_disatt)))
            if np.isfinite(cos_disatt) else float("nan")
        ),
        inter_fold_cosine_mean=float(np.mean(inter)) if inter else float("nan"),
        inter_fold_cosine_std=float(np.std(inter, ddof=1)) if len(inter) > 1 else 0.0,
        chance_cosine_sd=float(chance_sd),
        cosine_in_chance_sd=float(cos_mean / chance_sd) if chance_sd > 0 else 0.0,
        w_agent_full=w_full,
    )


# ============================================================
# 4. CROSS-VALIDATED SAFETY MONITOR  (Observation 3)
# ============================================================

def _calibrate_threshold(scores: np.ndarray, labels: np.ndarray) -> float:
    """Pick the threshold maximising F1 over percentiles of the score set."""
    if len(scores) == 0:
        return 0.0
    candidates = np.percentile(scores, np.arange(5, 96, 1))
    best_t, best_f1 = float(np.median(scores)), -1.0
    for t in candidates:
        f1 = f1_score(labels, (scores > t).astype(int), zero_division=0)
        if f1 > best_f1:
            best_f1, best_t = f1, float(t)
    return best_t


def cross_validated_monitor(
    agent_harmful: np.ndarray,
    agent_benign: np.ndarray,
    layer_idx: int = -1,
    n_folds: int = 5,
    C: float = 1.0,
    seed: int = 42,
) -> CrossValidatedMonitorResult:
    """
    Evaluate the safety monitor with direction AND threshold fitted on train only.

    The original routine calibrated tau on the same scores it then scored,
    which guarantees an optimistic F1 for the same reason as the probe: with
    N << d the training scores are perfectly separable, so some threshold
    always achieves F1 = 1.0. Here each fold fits w and calibrates tau on its
    training partition, then predicts on the held-out partition. Predictions
    are pooled across folds before computing the metrics, so every sample is
    scored exactly once by a model that never saw it.
    """
    agent_harmful = np.asarray(agent_harmful, dtype=np.float64)
    agent_benign = np.asarray(agent_benign, dtype=np.float64)

    X = np.concatenate([agent_harmful, agent_benign], axis=0)
    y = np.concatenate([np.ones(len(agent_harmful)), np.zeros(len(agent_benign))])

    # In-sample reference (what the old pipeline reported)
    w_full = _fit_agent_direction(X, y, C=C, seed=seed)
    s_full = X @ w_full
    t_full = _calibrate_threshold(s_full, y)
    f1_in_sample = float(f1_score(y, (s_full > t_full).astype(int), zero_division=0))

    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=seed)
    y_pred = np.zeros(len(y), dtype=int)
    thresholds: List[float] = []

    for train_idx, test_idx in skf.split(X, y):
        w_k = _fit_agent_direction(X[train_idx], y[train_idx], C=C, seed=seed)
        tau_k = _calibrate_threshold(X[train_idx] @ w_k, y[train_idx])
        thresholds.append(tau_k)
        y_pred[test_idx] = (X[test_idx] @ w_k > tau_k).astype(int)

    tp = int(((y_pred == 1) & (y == 1)).sum())
    fp = int(((y_pred == 1) & (y == 0)).sum())
    fn = int(((y_pred == 0) & (y == 1)).sum())
    tn = int(((y_pred == 0) & (y == 0)).sum())

    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
    fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0

    return CrossValidatedMonitorResult(
        layer_idx=layer_idx,
        n_folds=n_folds,
        precision_oof=float(precision),
        recall_oof=float(recall),
        f1_oof=float(f1),
        fpr_oof=float(fpr),
        thresholds_per_fold=thresholds,
        f1_in_sample=f1_in_sample,
        n_harmful=len(agent_harmful),
        n_benign=len(agent_benign),
    )


# ============================================================
# 5. LAYER SELECTION WITHOUT POST-HOC INFLATION  (Observation 4)
# ============================================================

def select_layer_and_test(
    chat_harmful: Dict[int, np.ndarray],
    chat_benign: Dict[int, np.ndarray],
    agent_harmful: Dict[int, np.ndarray],
    n_folds: int = 5,
    n_permutations: int = 10000,
    seed: int = 42,
) -> Dict:
    """
    Split-sample layer selection, avoiding the winner's-curse in the reported p.

    Choosing the layer that maximises DeltaP and then testing the hypothesis on
    that same layer is post-hoc inference: the statistic is biased upward and
    the type-I error rate exceeds the nominal level.

    Here the prompts are split in half. The selection half picks the layer; the
    inference half runs the test on the pre-committed layer only. The test is
    therefore performed on data that played no part in the selection.

    The Bonferroni-adjusted alpha over all candidate layers is also returned,
    so the alternative correction is available without a second run.

    Returns a dict with the selected layer, the inference-half test result, the
    per-layer selection scores, and the adjusted alpha.
    """
    layers = sorted(set(chat_harmful) & set(chat_benign) & set(agent_harmful))
    if not layers:
        raise ValueError("No layer is present in all three activation dicts.")

    n = len(chat_harmful[layers[0]])
    rng = np.random.default_rng(seed)
    perm = rng.permutation(n)
    sel_idx, inf_idx = perm[: n // 2], perm[n // 2:]

    m = len(chat_benign[layers[0]])
    perm_b = rng.permutation(m)
    sel_idx_b, inf_idx_b = perm_b[: m // 2], perm_b[m // 2:]

    # --- Selection half: rank layers by DeltaP ---
    selection_scores: Dict[int, float] = {}
    for l in layers:
        d_l = _diff_in_means_direction(
            chat_harmful[l][sel_idx], chat_benign[l][sel_idx_b]
        )
        gap = float(
            (chat_harmful[l][sel_idx] @ d_l).mean()
            - (agent_harmful[l][sel_idx] @ d_l).mean()
        )
        selection_scores[l] = gap

    chosen = max(selection_scores, key=selection_scores.get)

    # --- Inference half: cross-fitted test on the pre-committed layer only ---
    result = cross_fitted_projection_gap(
        chat_harmful[chosen][inf_idx],
        chat_benign[chosen][inf_idx_b],
        agent_harmful[chosen][inf_idx],
        layer_idx=chosen,
        n_folds=min(n_folds, len(inf_idx)),
        n_permutations=n_permutations,
        seed=seed,
    )

    return {
        "selected_layer": int(chosen),
        "selection_scores": selection_scores,
        "n_selection": int(len(sel_idx)),
        "n_inference": int(len(inf_idx)),
        "result": result,
        "bonferroni_alpha": 0.05 / len(layers),
        "n_layers_tested": len(layers),
    }


# ============================================================
# 6. REPORTING
# ============================================================

def format_gap_report(res: CrossFittedGapResult) -> str:
    """Human-readable comparison of naive and cross-fitted estimates."""
    n, c = res.naive_stats, res.crossfit_stats
    ratio = "n/a" if not np.isfinite(res.bias_ratio) else f"{res.bias_ratio:+.1%}"
    lines = [
        "=" * 72,
        f"CROSS-FITTED PROJECTION GAP  (layer {res.layer_idx}, K={res.n_folds})",
        "=" * 72,
        f"{'':<26}{'naive (in-sample)':>21}{'cross-fitted':>21}",
        "-" * 72,
        f"{'DeltaP':<26}{n.delta_p:>21.4f}{c.delta_p:>21.4f}",
        f"{'mean chat':<26}{n.mean_a:>21.4f}{c.mean_a:>21.4f}",
        f"{'mean agent':<26}{n.mean_b:>21.4f}{c.mean_b:>21.4f}",
        f"{'Cohen d (paired)':<26}{n.cohens_d_paired:>21.4f}{c.cohens_d_paired:>21.4f}",
        f"{'Cohen d (pooled)':<26}{n.cohens_d_pooled:>21.4f}{c.cohens_d_pooled:>21.4f}",
        f"{'implied pair corr r':<26}{n.implied_pair_correlation:>21.4f}"
        f"{c.implied_pair_correlation:>21.4f}",
        f"{'permutation p':<26}{n.p_value_permutation:>21.4f}{c.p_value_permutation:>21.4f}",
        f"{'bootstrap CI low':<26}{n.ci_lower:>21.4f}{c.ci_lower:>21.4f}",
        f"{'bootstrap CI high':<26}{n.ci_upper:>21.4f}{c.ci_upper:>21.4f}",
        f"{'pairs decreasing':<26}{str(n.n_decreasing) + '/' + str(n.n_pairs):>21}"
        f"{str(c.n_decreasing) + '/' + str(c.n_pairs):>21}",
        "-" * 72,
        f"Own-sample bias in DeltaP : {res.bias_estimate:+.4f}  ({ratio} of the "
        "cross-fitted estimate)",
        "",
        "  Report the CROSS-FITTED value as the estimate of the effect.",
        "  The naive value is retained only to quantify the bias.",
        f"  Permutation p of 0.0 means p < {n.p_value_floor:g}, not zero.",
        "=" * 72,
    ]
    return "\n".join(lines)


def format_direction_report(res: CrossValidatedDirectionResult) -> str:
    """Human-readable out-of-fold report for w_agent."""
    rel = res.split_half_reliability
    lines = [
        "=" * 72,
        f"CROSS-VALIDATED AGENT DIRECTION  (layer {res.layer_idx}, K={res.n_folds})",
        "=" * 72,
        f"  AUROC in-sample        : {res.auroc_in_sample:.4f}   "
        "<- guaranteed by Cover's theorem, NOT evidence",
        f"  AUROC out-of-fold      : {res.auroc_oof_mean:.4f} "
        f"(sd {res.auroc_oof_std:.4f})   <- report this one",
        f"  per-fold               : "
        + ", ".join(f"{a:.3f}" for a in res.auroc_oof_folds),
        "",
        "  --- alignment with d_chat ---",
        f"  cos measured           : {res.cosine_with_d_chat_mean:.4f} "
        f"(sd {res.cosine_with_d_chat_std:.4f})",
        f"  angle measured         : {res.angle_deg_mean:.1f} deg   "
        "<- UPPER BOUND, attenuated",
        f"  chance cosine sd       : {res.chance_cosine_sd:.5f}  "
        f"-> measured is {res.cosine_in_chance_sd:.1f} sd from chance",
        "",
        "  --- reliability and disattenuation ---",
        f"  split-half reliability : {rel:.4f} "
        f"(sd {res.split_half_reliability_std:.4f})   [DISJOINT halves]",
        f"  attenuation factor     : {res.attenuation_factor:.4f}   = sqrt(reliability)",
        f"  cos disattenuated      : {res.cosine_disattenuated:.4f}",
        f"  angle disattenuated    : {res.angle_deg_disattenuated:.1f} deg   "
        "<- bias-corrected estimate",
        "",
        f"  inter-fold cos(wi,wj)  : {res.inter_fold_cosine_mean:.4f}   "
        "[DIAGNOSTIC ONLY]",
        "    ^ inflated: K-fold training sets overlap, so their noise is",
        "      correlated. Never use this as the reliability ceiling.",
    ]
    if np.isfinite(rel):
        if rel < 0.10:
            lines += [
                "",
                "    VERDICT: w_agent is NOT reproducible at this sample size.",
                "             Report only that the alignment differs from chance.",
                "             Do not quote any angle, corrected or otherwise.",
            ]
        elif rel < 0.50:
            lines += [
                "",
                "    VERDICT: w_agent is weakly reproducible. The disattenuated",
                "             angle is a rough estimate with wide uncertainty;",
                "             quote it as a range, never to two decimals.",
            ]
        else:
            lines += [
                "",
                "    VERDICT: w_agent is reproducible. The disattenuated angle",
                "             is interpretable as a point estimate.",
            ]
    lines.append("=" * 72)
    return "\n".join(lines)


def format_monitor_report(res: CrossValidatedMonitorResult) -> str:
    """Human-readable out-of-fold report for the safety monitor."""
    return "\n".join([
        "=" * 72,
        f"CROSS-VALIDATED SAFETY MONITOR  (layer {res.layer_idx}, K={res.n_folds})",
        "=" * 72,
        f"  F1 in-sample   : {res.f1_in_sample:.4f}   <- threshold calibrated on the "
        "evaluation set",
        f"  F1 out-of-fold : {res.f1_oof:.4f}   <- report this one",
        f"  Precision      : {res.precision_oof:.4f}",
        f"  Recall         : {res.recall_oof:.4f}",
        f"  FPR            : {res.fpr_oof:.4f}",
        f"  thresholds     : " + ", ".join(f"{t:.3f}" for t in res.thresholds_per_fold),
        f"  samples        : {res.n_harmful} harmful + {res.n_benign} benign",
        "=" * 72,
    ])
